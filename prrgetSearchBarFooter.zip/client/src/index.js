import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.jsx';
import Footer from './Footer.jsx';

ReactDOM.render(
    <App />,
  document.getElementById('search')
);

ReactDOM.render(
  <Footer />,
document.getElementById('footer')
);
